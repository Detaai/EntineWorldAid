// Randeth Vision filter script
const fileInput = document.getElementById('fileInput');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });

const startCamBtn = document.getElementById('startCam');
const stopCamBtn = document.getElementById('stopCam');
const downloadBtn = document.getElementById('downloadBtn');

const greenRet = document.getElementById('greenRet'); // percent
const greenFlat = document.getElementById('greenFlat'); // percent
const forceMerge = document.getElementById('forceMerge');
const bBoost = document.getElementById('bBoost');

let videoStream = null;
let videoEl = null;
let running = false;

function resizeCanvas(w,h){
  canvas.width = w;
  canvas.height = h;
}

function applyRandethVisionToImageData(imgData){
  const px = imgData.data;
  const len = px.length;

  // parameters from UI
  const greenRetPct = parseFloat(greenRet.value)/100.0;
  const greenFlatPct = parseFloat(greenFlat.value)/100.0;
  const forceMergeOn = forceMerge.checked;
  const boost = parseFloat(bBoost.value)/100.0;

  for(let i=0;i<len;i+=4){
    const r = px[i], g = px[i+1], b = px[i+2], a = px[i+3];

    // luminance (sRGB weights)
    let gray = 0.2126*r + 0.7152*g + 0.0722*b;

    // green retention: small fraction of green adds to brightness
    const greenSense = g * greenRetPct;

    // flatten green differences (compress)
    const greenFlatVal = g * greenFlatPct;

    let final = gray + greenSense + greenFlatVal;

    // Force-merge: if pixel is green-dominant (g > r && g > b) push into narrow band
    if(forceMergeOn && g > r && g > b){
      // push to mid brightness band; tune factors for effect
      final = (final * 0.7) + 90;
    }

    // Optional small boost for low-light glowing greens
    if(g > 120 && (b>60 || b>g*0.5)){
      // if it's bioluminescent-like, boost slightly
      final = Math.min(255, final + (boost * 80));
    }

    // Clamp and write back as grayscale
    const out = Math.max(0, Math.min(255, Math.round(final)));
    px[i] = px[i+1] = px[i+2] = out;
    px[i+3] = a;
  }
  return imgData;
}

function drawImageToCanvas(img){
  resizeCanvas(img.width, img.height);
  ctx.drawImage(img,0,0);
  let id = ctx.getImageData(0,0,canvas.width, canvas.height);
  id = applyRandethVisionToImageData(id);
  ctx.putImageData(id,0,0);
}

fileInput.addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const img = new Image();
  img.onload = ()=> drawImageToCanvas(img);
  img.src = URL.createObjectURL(file);
});

startCamBtn.addEventListener('click', async ()=>{
  if(running) return;
  try{
    videoStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
  }catch(err){
    alert('Could not start camera: ' + err.message);
    return;
  }
  videoEl = document.createElement('video');
  videoEl.srcObject = videoStream;
  videoEl.play();

  videoEl.addEventListener('loadedmetadata', ()=>{
    resizeCanvas(videoEl.videoWidth, videoEl.videoHeight);
    running = true;
    renderLoop();
  });
});

stopCamBtn.addEventListener('click', ()=>{
  if(videoStream){
    const tracks = videoStream.getTracks();
    tracks.forEach(t=>t.stop());
    videoStream = null;
    videoEl = null;
    running = false;
  }
});

function renderLoop(){
  if(!running || !videoEl) return;
  ctx.drawImage(videoEl,0,0,canvas.width, canvas.height);
  let id = ctx.getImageData(0,0,canvas.width, canvas.height);
  id = applyRandethVisionToImageData(id);
  ctx.putImageData(id,0,0);
  requestAnimationFrame(renderLoop);
}

downloadBtn.addEventListener('click', ()=>{
  const link = document.createElement('a');
  link.download = 'randeth_view.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
});

// live update when sliders change
[greenRet, greenFlat, forceMerge, bBoost].forEach(el=>{
  el.addEventListener('input', ()=>{
    // if static image loaded, reapply
    if(!videoEl && canvas.width>0 && canvas.height>0 && !running){
      try{
        const imgData = ctx.getImageData(0,0,canvas.width,canvas.height);
        const out = applyRandethVisionToImageData(imgData);
        ctx.putImageData(out,0,0);
      }catch(e){ /* ignore if no image present */ }
    }
  });
});
